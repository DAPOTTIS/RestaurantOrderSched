#ifndef CLI_H
#define CLI_H



class CLI {
public:
    void init();
};



#endif //CLI_H
