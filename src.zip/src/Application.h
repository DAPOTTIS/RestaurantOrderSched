#ifndef APPLICATION_H
#define APPLICATION_H



namespace App {
    void MenuPicker();
    void SchedQueues();
    void RenderUI();
};



#endif //APPLICATION_H
