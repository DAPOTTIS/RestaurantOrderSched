#ifndef SCHEDULER_H
#define SCHEDULER_H



class Scheduler {
private:
    int cpuTime;
};



#endif //SCHEDULER_H
